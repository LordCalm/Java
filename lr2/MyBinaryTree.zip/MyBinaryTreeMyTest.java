package lr2;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

public class MyBinaryTreeMyTest {
    @Test
    void testAddAndContains() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(5);
        tree.add(3);
        tree.add(7);

        assertTrue(tree.containsNode(5));
        assertTrue(tree.containsNode(3));
        assertTrue(tree.containsNode(7));
        assertFalse(tree.containsNode(10));
    }

    @Test
    void testDeleteLeafNode() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(5);
        tree.add(3);
        tree.add(7);

        tree.delete(3);
        assertFalse(tree.containsNode(3));
        assertTrue(tree.containsNode(5));
        assertTrue(tree.containsNode(7));
    }

    @Test
    void testDeleteNodeWithOneChild() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(5);
        tree.add(3);
        tree.add(4); // 3 has one child 4

        tree.delete(3);
        assertFalse(tree.containsNode(3));
        assertTrue(tree.containsNode(4));
        assertTrue(tree.containsNode(5));
    }

    @Test
    void testDeleteNodeWithTwoChildren() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(5);
        tree.add(3);
        tree.add(7);
        tree.add(6);
        tree.add(8);

        tree.delete(7);
        assertFalse(tree.containsNode(7));
        assertTrue(tree.containsNode(6));
        assertTrue(tree.containsNode(8));
    }

    @Test
    void testTraverseInOrder() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(5);
        tree.add(3);
        tree.add(7);
        tree.add(4);

        List<Integer> result = new ArrayList<>();
        tree.traverseInOrder(result::add);

        // Должен быть отсортированный порядок
        assertEquals(List.of(3, 4, 5, 7), result);
    }

    @Test
    void testGetByIndex() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(5);
        tree.add(3);
        tree.add(7);
        tree.add(4);

        assertEquals(3, tree.getByIndex(0));
        assertEquals(4, tree.getByIndex(1));
        assertEquals(5, tree.getByIndex(2));
        assertEquals(7, tree.getByIndex(3));

        // Проверка выхода за пределы
        assertThrows(IndexOutOfBoundsException.class, () -> tree.getByIndex(4));
    }

    // Вспомогательный метод для вычисления высоты дерева
    private <T extends Comparable<T>> int getHeight(MyBinaryTree<T>.MyNode node) {
        if (node == null) return 0;
        try {
            var leftField = node.getClass().getDeclaredField("left");
            var rightField = node.getClass().getDeclaredField("right");
            leftField.setAccessible(true);
            rightField.setAccessible(true);
            MyBinaryTree<T>.MyNode left = (MyBinaryTree<T>.MyNode) leftField.get(node);
            MyBinaryTree<T>.MyNode right = (MyBinaryTree<T>.MyNode) rightField.get(node);
            return 1 + Math.max(getHeight(left), getHeight(right));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testBalancePreservesOrder() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        // создаём заведомо несбалансированное дерево (всё вправо)
        for (int i = 1; i <= 7; i++) {
            tree.add(i);
        }

        List<Integer> before = tree.toList();
        tree.balance();
        List<Integer> after = tree.toList();

        // порядок элементов должен быть тем же
        assertEquals(before, after, "Порядок элементов после балансировки должен сохраняться");
    }

    @Test
    void testBalanceReducesHeight() throws Exception {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        for (int i = 1; i <= 15; i++) {
            tree.add(i);
        }

        // доступ к root через reflection
        var rootField = tree.getClass().getDeclaredField("root");
        rootField.setAccessible(true);
        var rootBefore = (MyBinaryTree<Integer>.MyNode) rootField.get(tree);
        int heightBefore = getHeight(rootBefore);

        tree.balance();

        var rootAfter = (MyBinaryTree<Integer>.MyNode) rootField.get(tree);
        int heightAfter = getHeight(rootAfter);

        // сбалансированное дерево должно быть ниже
        assertTrue(heightAfter < heightBefore, 
            "Высота дерева должна уменьшиться после балансировки");
    }

    @Test
    void testBalanceOnEmptyTree() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        assertDoesNotThrow(tree::balance, "Пустое дерево не должно вызывать ошибок при балансировке");
        assertTrue(tree.toList().isEmpty(), "После балансировки пустое дерево должно оставаться пустым");
    }

    @Test
    void testBalanceSingleNodeTree() {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        tree.add(42);
        tree.balance();
        List<Integer> list = tree.toList();
        assertEquals(1, list.size(), "Одноузловое дерево должно оставаться неизменным");
        assertEquals(42, list.get(0));
    }

    @Test
    void testBalancedTreeRemainsBalanced() throws Exception {
        MyBinaryTree<Integer> tree = new MyBinaryTree<>();
        int[] values = {4, 2, 6, 1, 3, 5, 7};
        for (int v : values) tree.add(v);

        var rootField = tree.getClass().getDeclaredField("root");
        rootField.setAccessible(true);
        var rootBefore = (MyBinaryTree<Integer>.MyNode) rootField.get(tree);
        int heightBefore = getHeight(rootBefore);

        tree.balance();

        var rootAfter = (MyBinaryTree<Integer>.MyNode) rootField.get(tree);
        int heightAfter = getHeight(rootAfter);

        assertTrue(Math.abs(heightBefore - heightAfter) <= 1,
            "Сбалансированное дерево не должно существенно меняться после повторной балансировки");
    }
}